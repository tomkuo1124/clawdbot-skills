#!/usr/bin/env python3
"""
YouTube Video Summarizer v2
===========================
Downloads YouTube subtitles (preferred) or transcribes with Groq Whisper,
then generates summary with Claude.

Usage:
    python yt_summary.py "https://youtube.com/watch?v=xxxxx"
    python yt_summary.py "https://youtube.com/watch?v=xxxxx" --whisper

Features:
    - Default: Use YouTube auto-generated subtitles (fast)
    - --whisper: Force Groq Whisper transcription (accurate)
    - Auto fallback to Whisper if no subtitles available
    - Subtitle language priority: zh-TW > zh-Hans > zh > en > ja
"""

import os
import sys
import re
import argparse
import tempfile
import time
from datetime import datetime
from pathlib import Path
from typing import Optional

try:
    import yt_dlp
except ImportError:
    print("❌ 請安裝 yt-dlp: pip install yt-dlp")
    sys.exit(1)

try:
    from groq import Groq
except ImportError:
    print("❌ 請安裝 groq: pip install groq")
    sys.exit(1)

try:
    from anthropic import Anthropic
    HAS_ANTHROPIC = True
except ImportError:
    HAS_ANTHROPIC = False
    Anthropic = None  # 方案 B 不需要

try:
    from pydub import AudioSegment
except ImportError:
    print("❌ 請安裝 pydub: pip install pydub")
    sys.exit(1)


# =============================================================================
# Configuration
# =============================================================================

MAX_AUDIO_SIZE_MB = 20  # Groq limit is 25MB, we use 20MB for safety
SEGMENT_DURATION_MS = 10 * 60 * 1000  # 10 minutes per segment
OVERLAP_MS = 30 * 1000  # 30 seconds overlap

OUTPUT_DIR = Path("./output")
WHISPER_MODEL = "whisper-large-v3-turbo"
CLAUDE_MODEL = "claude-sonnet-4-20250514"

# Subtitle language priority (Taiwan user preference)
SUBTITLE_LANGS = ['zh-TW', 'zh-Hant', 'zh-Hans', 'zh', 'en', 'ja']

# API retry settings
MAX_RETRIES = 3
RETRY_DELAY = 2  # seconds


# =============================================================================
# Error Classes
# =============================================================================

class VideoError(Exception):
    """Base error for video-related issues"""
    pass

class PrivateVideoError(VideoError):
    """Video is private or requires authentication"""
    pass

class LiveStreamError(VideoError):
    """Video is a live stream"""
    pass

class NoSubtitlesError(VideoError):
    """No subtitles available"""
    pass


# =============================================================================
# YouTube Utilities
# =============================================================================

def get_video_info(url: str) -> dict:
    """
    Extract video information without downloading.
    Raises appropriate errors for problematic videos.
    """
    print(f"🔍 檢查影片資訊...")
    
    ydl_opts = {
        'quiet': True,
        'no_warnings': True,
        'extract_flat': False,
    }
    
    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=False)
            
            # Check for live stream
            if info.get('is_live'):
                raise LiveStreamError("此影片是直播，無法處理")
            
            # Check for upcoming premiere
            if info.get('live_status') == 'is_upcoming':
                raise LiveStreamError("此影片尚未首播")
            
            video_info = {
                'id': info.get('id'),
                'title': info.get('title', 'Unknown'),
                'channel': info.get('uploader', 'Unknown'),
                'duration': info.get('duration', 0),
                'url': url,
                'subtitles': info.get('subtitles', {}),
                'automatic_captions': info.get('automatic_captions', {}),
            }
            
            print(f"✅ 影片: {video_info['title']}")
            print(f"   頻道: {video_info['channel']}")
            print(f"   時長: {format_duration(video_info['duration'])}")
            
            return video_info
            
    except yt_dlp.utils.DownloadError as e:
        error_msg = str(e).lower()
        if 'private' in error_msg or 'sign in' in error_msg:
            raise PrivateVideoError("此影片為私人影片或需要登入")
        elif 'unavailable' in error_msg:
            raise VideoError("此影片無法存取")
        else:
            raise VideoError(f"無法取得影片資訊: {e}")


def download_subtitles(url: str, video_info: dict, output_dir: Path) -> Optional[tuple[str, str]]:
    """
    Download subtitles from YouTube.
    Returns: (subtitle_text, language) or None if not available
    """
    print(f"📝 嘗試下載字幕...")
    
    # Check available subtitles
    available_subs = video_info.get('subtitles', {})
    auto_subs = video_info.get('automatic_captions', {})
    
    # Find best subtitle language
    selected_lang = None
    is_auto = False
    
    # First, try manual subtitles
    for lang in SUBTITLE_LANGS:
        if lang in available_subs:
            selected_lang = lang
            break
        # Also check without region code
        lang_base = lang.split('-')[0]
        for avail_lang in available_subs:
            if avail_lang.startswith(lang_base):
                selected_lang = avail_lang
                break
        if selected_lang:
            break
    
    # If no manual subs, try auto-generated
    if not selected_lang:
        for lang in SUBTITLE_LANGS:
            if lang in auto_subs:
                selected_lang = lang
                is_auto = True
                break
            lang_base = lang.split('-')[0]
            for avail_lang in auto_subs:
                if avail_lang.startswith(lang_base):
                    selected_lang = avail_lang
                    is_auto = True
                    break
            if selected_lang:
                break
    
    if not selected_lang:
        print("   ⚠️ 找不到支援的字幕語言")
        return None
    
    print(f"   找到字幕: {selected_lang} ({'自動產生' if is_auto else '手動上傳'})")
    
    # Download subtitle
    ydl_opts = {
        'quiet': True,
        'no_warnings': True,
        'skip_download': True,
        'writesubtitles': not is_auto,
        'writeautomaticsub': is_auto,
        'subtitleslangs': [selected_lang],
        'subtitlesformat': 'vtt/srt/best',
        'outtmpl': str(output_dir / '%(id)s'),
    }
    
    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            ydl.download([url])
        
        # Find downloaded subtitle file
        video_id = video_info['id']
        for ext in ['vtt', 'srt']:
            sub_path = output_dir / f"{video_id}.{selected_lang}.{ext}"
            if sub_path.exists():
                subtitle_text = parse_subtitle_file(sub_path)
                print(f"✅ 字幕下載完成 ({len(subtitle_text)} 字元)")
                return subtitle_text, selected_lang
        
        print("   ⚠️ 字幕檔案未找到")
        return None
        
    except Exception as e:
        print(f"   ⚠️ 字幕下載失敗: {e}")
        return None


def parse_subtitle_file(path: Path) -> str:
    """
    Parse VTT or SRT subtitle file to plain text.
    """
    content = path.read_text(encoding='utf-8')
    
    # Remove VTT header
    if content.startswith('WEBVTT'):
        content = re.sub(r'^WEBVTT.*?\n\n', '', content, flags=re.DOTALL)
    
    # Remove timestamps and formatting
    lines = []
    for line in content.split('\n'):
        line = line.strip()
        
        # Skip empty lines
        if not line:
            continue
        
        # Skip numeric cue identifiers (SRT format)
        if re.match(r'^\d+$', line):
            continue
        
        # Skip timestamp lines
        if re.match(r'^\d{2}:\d{2}', line) or '-->' in line:
            continue
        
        # Remove VTT positioning tags
        line = re.sub(r'<[^>]+>', '', line)
        
        # Remove duplicate lines (common in auto-generated subs)
        if lines and line == lines[-1]:
            continue
        
        lines.append(line)
    
    return ' '.join(lines)


# =============================================================================
# Audio Download & Processing
# =============================================================================

def download_audio(url: str, output_dir: Path) -> tuple[Path, dict]:
    """
    Download audio from YouTube video.
    Returns: (audio_path, video_info)
    """
    print(f"📥 下載音檔中...")
    
    ydl_opts = {
        'format': 'bestaudio[ext=m4a]/bestaudio/best',
        'outtmpl': str(output_dir / '%(id)s.%(ext)s'),
        'postprocessors': [{
            'key': 'FFmpegExtractAudio',
            'preferredcodec': 'mp3',
            'preferredquality': '128',  # Lower quality for faster processing
        }],
        'quiet': True,
        'no_warnings': True,
    }
    
    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        info = ydl.extract_info(url, download=True)
        video_id = info.get('id')
        
        audio_path = output_dir / f"{video_id}.mp3"
        
        if not audio_path.exists():
            # Try other extensions
            for ext in ['mp3', 'm4a', 'webm', 'opus']:
                alt_path = output_dir / f"{video_id}.{ext}"
                if alt_path.exists():
                    audio_path = alt_path
                    break
        
        if not audio_path.exists():
            raise VideoError("音檔下載失敗")
        
        print(f"✅ 音檔下載完成: {get_file_size_mb(audio_path):.1f} MB")
        return audio_path, info


def format_duration(seconds: int) -> str:
    """Format seconds to HH:MM:SS or MM:SS"""
    if not seconds:
        return "未知"
    if seconds < 3600:
        return f"{seconds // 60}:{seconds % 60:02d}"
    return f"{seconds // 3600}:{(seconds % 3600) // 60:02d}:{seconds % 60:02d}"


def get_file_size_mb(path: Path) -> float:
    """Get file size in MB"""
    return path.stat().st_size / (1024 * 1024)


def segment_audio(audio_path: Path, output_dir: Path) -> list[Path]:
    """
    Split audio file into segments if larger than MAX_AUDIO_SIZE_MB.
    Returns list of segment paths.
    """
    size_mb = get_file_size_mb(audio_path)
    
    if size_mb <= MAX_AUDIO_SIZE_MB:
        return [audio_path]
    
    print(f"📎 音檔超過 {MAX_AUDIO_SIZE_MB}MB，進行分段處理...")
    
    audio = AudioSegment.from_file(audio_path)
    total_duration = len(audio)
    segments = []
    
    start = 0
    segment_num = 1
    
    while start < total_duration:
        end = min(start + SEGMENT_DURATION_MS, total_duration)
        segment = audio[start:end]
        
        segment_path = output_dir / f"segment_{segment_num:03d}.mp3"
        segment.export(segment_path, format="mp3", bitrate="128k")
        segments.append(segment_path)
        
        print(f"   分段 {segment_num}: {start // 1000}s - {end // 1000}s")
        
        if end < total_duration:
            start = end - OVERLAP_MS
        else:
            start = end
        
        segment_num += 1
    
    print(f"✅ 分段完成: {len(segments)} 個片段")
    return segments


# =============================================================================
# Transcription (Groq Whisper)
# =============================================================================

def transcribe_audio(audio_paths: list[Path]) -> tuple[str, str]:
    """
    Transcribe audio file(s) using Groq Whisper with retry logic.
    Returns: (full_transcript, detected_language)
    """
    print(f"🎙️ 語音轉文字中 (Groq Whisper)...")
    
    client = Groq()
    transcripts = []
    detected_lang = None
    
    for i, audio_path in enumerate(audio_paths):
        if len(audio_paths) > 1:
            print(f"   處理分段 {i + 1}/{len(audio_paths)}...")
        
        # Retry logic
        for attempt in range(MAX_RETRIES):
            try:
                with open(audio_path, "rb") as audio_file:
                    response = client.audio.transcriptions.create(
                        model=WHISPER_MODEL,
                        file=audio_file,
                        response_format="verbose_json",
                    )
                
                transcripts.append(response.text)
                
                if detected_lang is None and hasattr(response, 'language'):
                    detected_lang = response.language
                
                break  # Success
                
            except Exception as e:
                if attempt < MAX_RETRIES - 1:
                    print(f"   ⚠️ 重試中 ({attempt + 1}/{MAX_RETRIES})...")
                    time.sleep(RETRY_DELAY)
                else:
                    raise Exception(f"Whisper API 失敗: {e}")
    
    # Merge transcripts
    full_transcript = "\n\n".join(transcripts)
    
    print(f"✅ 轉錄完成 ({len(full_transcript)} 字元)")
    if detected_lang:
        print(f"   偵測語言: {detected_lang}")
    
    return full_transcript, detected_lang or "auto"


# =============================================================================
# Summarization (Claude)
# =============================================================================

def summarize_transcript(transcript: str, video_info: dict) -> str:
    """
    Generate structured summary using Claude.
    Always output in Traditional Chinese.
    """
    print(f"📝 生成摘要中 (Claude)...")
    
    client = Anthropic()
    
    prompt = f"""你是一個專業的內容摘要助手。以下是 YouTube 影片「{video_info['title']}」的字幕/轉錄內容。

請用**繁體中文**提供結構化的重點摘要，包含：

## 📌 核心主題
一句話說明影片在講什麼

## 🎯 關鍵要點
3-7 個最重要的觀點或資訊（bullet points）

## 💡 重要細節
任何值得注意的具體數據、例子或引述

## 🔚 結論/行動建議
影片的結論或對觀眾的建議

## 🏷️ 標籤
3-5 個關鍵字標籤

---

字幕/轉錄內容：

{transcript[:50000]}
"""  # Truncate if too long
    
    # Retry logic
    for attempt in range(MAX_RETRIES):
        try:
            response = client.messages.create(
                model=CLAUDE_MODEL,
                max_tokens=4096,
                messages=[
                    {"role": "user", "content": prompt}
                ]
            )
            
            summary = response.content[0].text
            print(f"✅ 摘要完成")
            return summary
            
        except Exception as e:
            if attempt < MAX_RETRIES - 1:
                print(f"   ⚠️ 重試中 ({attempt + 1}/{MAX_RETRIES})...")
                time.sleep(RETRY_DELAY)
            else:
                raise Exception(f"Claude API 失敗: {e}")


# =============================================================================
# Output Generation
# =============================================================================

def generate_output(
    video_info: dict,
    transcript: str,
    summary: Optional[str],
    source: str,
    output_dir: Path
) -> Path:
    """
    Generate final Markdown output file.
    """
    # Create safe filename
    title = video_info['title']
    safe_title = re.sub(r'[<>:"/\\|?*]', '_', title)
    safe_title = safe_title[:80]
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_path = output_dir / f"{safe_title}_{timestamp}.md"
    
    duration_str = format_duration(video_info['duration'])
    
    # Build content based on whether summary exists
    if summary:
        content = f"""# {title}

## 📋 影片資訊
- **連結**: {video_info['url']}
- **頻道**: {video_info['channel']}
- **時長**: {duration_str}
- **轉錄來源**: {source}
- **處理時間**: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}

---

{summary}

---

## 📝 完整字幕/轉錄

<details>
<summary>點擊展開</summary>

{transcript}

</details>
"""
    else:
        # Transcript-only mode
        content = f"""# {title}

## 📋 影片資訊
- **連結**: {video_info['url']}
- **頻道**: {video_info['channel']}
- **時長**: {duration_str}
- **轉錄來源**: {source}
- **處理時間**: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}

---

## 📝 字幕/轉錄內容

{transcript}
"""
    
    output_path.write_text(content, encoding='utf-8')
    print(f"💾 輸出檔案: {output_path}")
    
    return output_path


# =============================================================================
# Main
# =============================================================================

def main():
    parser = argparse.ArgumentParser(
        description='YouTube 影片摘要工具',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
範例:
  python yt_summary.py "https://youtube.com/watch?v=xxxxx"
  python yt_summary.py "https://youtu.be/xxxxx" --whisper
        '''
    )
    parser.add_argument('url', help='YouTube 影片 URL')
    parser.add_argument(
        '--whisper', '-w',
        action='store_true',
        help='強制使用 Whisper 轉錄（忽略 YouTube 字幕）'
    )
    parser.add_argument(
        '--output', '-o',
        type=Path,
        default=OUTPUT_DIR,
        help=f'輸出目錄（預設: {OUTPUT_DIR}）'
    )
    parser.add_argument(
        '--transcript-only', '-t',
        action='store_true',
        help='只輸出轉錄/字幕文字（不做摘要）'
    )
    
    args = parser.parse_args()
    url = args.url
    force_whisper = args.whisper
    output_dir = args.output
    transcript_only = args.transcript_only
    
    # Validate URL
    if 'youtube.com' not in url and 'youtu.be' not in url:
        print("❌ 請提供有效的 YouTube 連結")
        sys.exit(1)
    
    # Check environment variables
    groq_key = os.environ.get('GROQ_API_KEY')
    if not groq_key:
        # Try to read from User environment on Windows
        try:
            import winreg
            key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, r'Environment')
            groq_key, _ = winreg.QueryValueEx(key, 'GROQ_API_KEY')
            os.environ['GROQ_API_KEY'] = groq_key
            winreg.CloseKey(key)
        except:
            pass
    
    if not os.environ.get('GROQ_API_KEY'):
        print("❌ 請設定環境變數 GROQ_API_KEY")
        sys.exit(1)
    
    if not transcript_only and not os.environ.get('ANTHROPIC_API_KEY'):
        print("❌ 請設定環境變數 ANTHROPIC_API_KEY（或使用 --transcript-only 只輸出轉錄）")
        sys.exit(1)
    
    # Create output directory
    output_dir.mkdir(exist_ok=True)
    
    print()
    print("=" * 50)
    print("🎬 YouTube 影片摘要工具 v2")
    print("=" * 50)
    print()
    
    # Use temp directory for intermediate files
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = Path(temp_dir)
        
        try:
            # Step 1: Get video info
            video_info = get_video_info(url)
            
            # Progress report for long videos
            if video_info['duration'] and video_info['duration'] > 600:  # > 10 min
                print(f"⏳ 影片較長，處理需要一些時間...")
            
            transcript = None
            source = None
            
            # Step 2: Try to get subtitles (unless --whisper)
            if not force_whisper:
                result = download_subtitles(url, video_info, temp_path)
                if result:
                    transcript, lang = result
                    source = f"YouTube 字幕 ({lang})"
            
            # Step 3: Fall back to Whisper if needed
            if transcript is None:
                if force_whisper:
                    print("🎙️ 使用 Whisper 轉錄（指定模式）")
                else:
                    print("🎙️ 字幕不可用，使用 Whisper 轉錄")
                
                audio_path, _ = download_audio(url, temp_path)
                segments = segment_audio(audio_path, temp_path)
                transcript, lang = transcribe_audio(segments)
                source = f"Groq Whisper ({lang})"
            
            # Step 4: Summarize (unless transcript-only mode)
            if transcript_only:
                summary = None
                print("📝 轉錄模式：跳過摘要")
            else:
                summary = summarize_transcript(transcript, video_info)
            
            # Step 5: Generate output
            output_path = generate_output(
                video_info, transcript, summary, source, output_dir
            )
            
            print()
            print("=" * 50)
            print("✨ 完成！")
            print(f"📄 輸出檔案: {output_path}")
            print("=" * 50)
            
            return str(output_path)
            
        except PrivateVideoError as e:
            print(f"\n🔒 {e}")
            sys.exit(1)
        except LiveStreamError as e:
            print(f"\n📺 {e}")
            sys.exit(1)
        except VideoError as e:
            print(f"\n❌ {e}")
            sys.exit(1)
        except KeyboardInterrupt:
            print("\n\n⚠️ 使用者中斷")
            sys.exit(130)
        except Exception as e:
            print(f"\n❌ 錯誤: {e}")
            raise


if __name__ == "__main__":
    main()
