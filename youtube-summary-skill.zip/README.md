# YouTube Summary Skill

摘要 YouTube 影片內容，支援字幕抓取和 Whisper 轉錄。

## 功能

- ✅ 自動抓取 YouTube 字幕（預設，快速）
- ✅ Groq Whisper 轉錄（準確，作為 fallback 或強制使用）
- ✅ 字幕語言優先順序：zh-TW > zh-Hans > en > ja
- ✅ 長影片自動分段處理
- ✅ 詳細結構化摘要（含具體例子和行動建議）
- ✅ 雙檔案輸出（轉錄 + 摘要）

## 安裝

### 快速安裝

```bash
# 進入 skill 目錄
cd skills/youtube-summary

# 安裝 Python 依賴
pip install -r requirements.txt
```

### 系統依賴

確保已安裝：
- Python 3.10+
- ffmpeg
- yt-dlp

```bash
# Windows
winget install ffmpeg
pip install yt-dlp

# macOS
brew install ffmpeg yt-dlp

# Linux
apt install ffmpeg
pip install yt-dlp
```

### 環境變數

```bash
# 設定 Groq API Key
export GROQ_API_KEY="your-groq-api-key"

# 取得 API Key: https://console.groq.com/
```

## 使用方式

### 在 Clawdbot 中使用

```
幫我摘要 https://youtube.com/watch?v=xxxxx
```

```
這個影片在講什麼 https://youtu.be/xxxxx
```

```
用 whisper 摘要 https://youtube.com/watch?v=xxxxx
```

### 命令行使用

```bash
# 預設模式（使用 YouTube 字幕）
python src/yt_summary.py "https://youtube.com/watch?v=xxx" --transcript-only

# 強制使用 Whisper
python src/yt_summary.py "https://youtube.com/watch?v=xxx" --whisper --transcript-only
```

## 輸出

```
yt-summary/output/
├── {影片標題}_{timestamp}.md    ← 完整轉錄
└── {影片標題}_summary.md        ← 詳細摘要
```

## 摘要格式

- 📌 核心主題
- 🎯 關鍵要點（含例子和特徵）
- 💡 重要觀點與細節（含金句）
- 🔚 行動建議（含具體做法）
- 🏷️ 標籤

## 授權

MIT License
