#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
YouTube Summary Skill - 安裝腳本
================================
自動安裝 YouTube 摘要工具到 Clawdbot workspace。

使用方式：
    python install.py

會自動：
1. 檢測 Clawdbot workspace
2. 檢查系統依賴
3. 安裝 Python 依賴
4. 複製檔案到正確位置
5. 提示設定環境變數
"""

import os
import sys
import shutil
import subprocess
import platform
from pathlib import Path

# 設定 stdout 編碼為 UTF-8
if sys.stdout.encoding != 'utf-8':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except AttributeError:
        pass  # Python < 3.7

# 顏色輸出
class Colors:
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    CYAN = '\033[96m'
    END = '\033[0m'

def print_color(color, msg):
    print(f"{color}{msg}{Colors.END}")

def print_success(msg):
    print_color(Colors.GREEN, f"✅ {msg}")

def print_warning(msg):
    print_color(Colors.YELLOW, f"⚠️ {msg}")

def print_error(msg):
    print_color(Colors.RED, f"❌ {msg}")

def print_info(msg):
    print_color(Colors.CYAN, f"ℹ️ {msg}")


def find_clawdbot_workspace():
    """找到 Clawdbot workspace 目錄"""
    # 常見位置
    possible_paths = [
        Path.home() / "clawd",
        Path.home() / "clawdbot",
        Path.cwd().parent,  # 如果在 skill 目錄裡
        Path.cwd().parent.parent,  # 如果在 skill/src 目錄裡
    ]
    
    for path in possible_paths:
        if (path / "AGENTS.md").exists() or (path / "skills").exists():
            return path
    
    # 嘗試從環境變數
    env_path = os.environ.get("CLAWD_HOME") or os.environ.get("CLAWDBOT_HOME")
    if env_path:
        return Path(env_path)
    
    return None


def check_command(cmd):
    """檢查命令是否可用"""
    try:
        subprocess.run(
            cmd.split(),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=10
        )
        return True
    except (subprocess.CalledProcessError, FileNotFoundError, subprocess.TimeoutExpired):
        return False


def check_dependencies():
    """檢查系統依賴"""
    print("\n[1/5] 檢查系統依賴...")
    
    deps = {
        "python": "python --version",
        "ffmpeg": "ffmpeg -version",
        "yt-dlp": "yt-dlp --version",
    }
    
    missing = []
    for name, cmd in deps.items():
        if check_command(cmd):
            print_success(f"{name} 已安裝")
        else:
            print_error(f"{name} 未安裝")
            missing.append(name)
    
    if missing:
        print_warning(f"\n缺少依賴: {', '.join(missing)}")
        print_info("請先安裝缺少的依賴：")
        if "ffmpeg" in missing:
            if platform.system() == "Windows":
                print("  winget install ffmpeg")
            elif platform.system() == "Darwin":
                print("  brew install ffmpeg")
            else:
                print("  apt install ffmpeg")
        if "yt-dlp" in missing:
            print("  pip install yt-dlp")
        return False
    
    return True


def install_pip_dependencies():
    """安裝 Python 依賴"""
    print("\n[2/5] 安裝 Python 依賴...")
    
    script_dir = Path(__file__).parent
    requirements_file = script_dir / "requirements.txt"
    
    if not requirements_file.exists():
        print_warning("requirements.txt 不存在，跳過")
        return True
    
    try:
        subprocess.run(
            [sys.executable, "-m", "pip", "install", "-r", str(requirements_file), "-q"],
            check=True
        )
        print_success("Python 依賴安裝完成")
        return True
    except subprocess.CalledProcessError as e:
        print_error(f"安裝失敗: {e}")
        return False


def copy_to_workspace(workspace):
    """複製 skill 到 workspace"""
    print("\n[3/5] 複製到 Clawdbot workspace...")
    
    script_dir = Path(__file__).parent
    skill_name = "youtube-summary"
    target_dir = workspace / "skills" / skill_name
    
    # 確保目標目錄存在
    target_dir.mkdir(parents=True, exist_ok=True)
    
    # 要複製的檔案
    files_to_copy = [
        "skill.yaml",
        "SKILL.md",
        "README.md",
        "requirements.txt",
    ]
    
    # 複製檔案
    for filename in files_to_copy:
        src = script_dir / filename
        dst = target_dir / filename
        if src.exists():
            # 如果源和目標相同，跳過
            if src.resolve() == dst.resolve():
                print_success(f"{filename} 已在正確位置")
            else:
                shutil.copy2(src, dst)
                print_success(f"複製 {filename}")
    
    # 複製 src 目錄
    src_dir = script_dir / "src"
    target_src_dir = target_dir / "src"
    if src_dir.exists():
        # 如果源和目標相同，跳過
        if src_dir.resolve() == target_src_dir.resolve():
            print_success("src/ 目錄已在正確位置")
        else:
            if target_src_dir.exists():
                shutil.rmtree(target_src_dir)
            shutil.copytree(src_dir, target_src_dir)
            print_success("複製 src/ 目錄")
    
    # 創建 output 目錄
    output_dir = workspace / "yt-summary" / "output"
    output_dir.mkdir(parents=True, exist_ok=True)
    print_success(f"創建 output 目錄: {output_dir}")
    
    return target_dir


def check_env_variables():
    """檢查環境變數"""
    print("\n[4/5] 檢查環境變數...")
    
    required_env = {
        "GROQ_API_KEY": "Groq API 金鑰（用於 Whisper 轉錄）",
    }
    
    missing = []
    for name, desc in required_env.items():
        # 檢查環境變數
        value = os.environ.get(name)
        
        # Windows: 也檢查 User 環境變數
        if not value and platform.system() == "Windows":
            try:
                import winreg
                key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, r'Environment')
                value, _ = winreg.QueryValueEx(key, name)
                winreg.CloseKey(key)
            except:
                pass
        
        if value:
            print_success(f"{name} 已設定")
        else:
            print_warning(f"{name} 未設定 — {desc}")
            missing.append(name)
    
    if missing:
        print_info("\n請設定以下環境變數：")
        for name in missing:
            if platform.system() == "Windows":
                print(f'  [System.Environment]::SetEnvironmentVariable("{name}", "your-key", "User")')
            else:
                print(f'  export {name}="your-key"')
        print_info("\n取得 GROQ_API_KEY: https://console.groq.com/")
    
    return len(missing) == 0


def print_summary(workspace, skill_dir):
    """打印安裝摘要"""
    print("\n[5/5] 安裝摘要")
    print("=" * 50)
    print_success("安裝完成！")
    print()
    print(f"📁 Skill 位置: {skill_dir}")
    print(f"📁 Output 位置: {workspace / 'yt-summary' / 'output'}")
    print()
    print("🚀 使用方式：")
    print('   在 Discord 對 Clawdbot 說：')
    print('   「幫我摘要 https://youtube.com/watch?v=xxxxx」')
    print()
    print("📝 命令行測試：")
    print(f'   python "{skill_dir / "src" / "yt_summary.py"}" "URL" --transcript-only')
    print("=" * 50)


def main():
    print("=" * 50)
    print("🎬 YouTube Summary Skill - 安裝程式")
    print("=" * 50)
    
    # 找到 workspace
    workspace = find_clawdbot_workspace()
    if not workspace:
        print_error("找不到 Clawdbot workspace！")
        print_info("請設定環境變數 CLAWD_HOME 或在 workspace 目錄下執行")
        sys.exit(1)
    
    print_success(f"找到 workspace: {workspace}")
    
    # 檢查依賴
    if not check_dependencies():
        print_error("\n請先安裝缺少的依賴，然後重新執行此腳本")
        sys.exit(1)
    
    # 安裝 pip 依賴
    if not install_pip_dependencies():
        print_error("\nPython 依賴安裝失敗")
        sys.exit(1)
    
    # 複製到 workspace
    skill_dir = copy_to_workspace(workspace)
    
    # 檢查環境變數
    env_ok = check_env_variables()
    
    # 打印摘要
    print_summary(workspace, skill_dir)
    
    if not env_ok:
        print_warning("\n⚠️ 請設定環境變數後再使用 Skill")
        sys.exit(0)
    
    sys.exit(0)


if __name__ == "__main__":
    main()
